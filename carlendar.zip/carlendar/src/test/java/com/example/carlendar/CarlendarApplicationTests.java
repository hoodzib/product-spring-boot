package com.example.carlendar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarlendarApplicationTests {

	@Test
	void contextLoads() {
	}

}
